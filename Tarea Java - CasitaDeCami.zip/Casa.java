public class Casa {

    protected String colorPrincipal;
    protected int pisos;
    protected int puertas;
    protected boolean tieneVentanas;
    protected boolean tieneJardin;

    public Casa(String colorPrincipal, int pisos, int puertas, boolean tieneVentanas, boolean tieneJardin) {
        this.colorPrincipal = colorPrincipal;
        this.pisos = pisos;
        this.puertas = puertas;
        this.tieneVentanas = tieneVentanas;
        this.tieneJardin = tieneJardin;
    }

    public String describir() {
        String desc = "--- Descripción general de la casa ---\n";
        desc += "Color principal: " + this.colorPrincipal + "\n";
        desc += "Número de pisos: " + this.pisos + "\n";
        desc += "Puertas: " + this.puertas + "\n";
        desc += "¿Tiene ventanas?: " + (this.tieneVentanas ? "Sí" : "No") + "\n";
        desc += "¿Tiene jardín?: " + (this.tieneJardin ? "Sí" : "No") + "\n";
        return desc;
    }

    public void pintar(String nuevoColor) {
        this.colorPrincipal = nuevoColor;
        System.out.println("La casa ha sido pintada de color " + nuevoColor);
    }
}

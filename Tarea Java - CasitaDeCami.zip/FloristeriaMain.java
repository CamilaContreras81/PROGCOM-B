public class FloristeriaMain {
    public static void main(String[] args) {

        CasaDeCami miCasita = new CasaDeCami();

        System.out.println(miCasita.describir());

        System.out.println("======================================================");
        System.out.println("                PINTANDO LA CASITA DE CAMI...");
        System.out.println("======================================================");

        miCasita.pintar("Lila Pastel");
        miCasita.pintarPuerta("Verde Menta");
        miCasita.pintarTecho("Celeste");
    }
}

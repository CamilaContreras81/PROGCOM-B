public class CasaDeCami extends Casa {

    private String colorLateral;
    private String colorPuerta;
    private String materialTecho;
    private String decoraciones;

    private int totalFloresDibujadas;
    private boolean tieneSol;
    private boolean tieneNube;

    private double anchoPuerta;
    private double altoPuerta;
    private String materialPuerta;

    public CasaDeCami() {
        super("Rosado con flores dibujadas", 1, 1, true, false);

        this.colorLateral = "Rosado claro";
        this.colorPuerta = "Amarillo";
        this.materialTecho = "Cartulina pintada de verde con marcador";
        this.decoraciones = "Flores de colores, nube azul, sol amarillo y pasto verde";

        this.totalFloresDibujadas = 6;
        this.tieneSol = true;
        this.tieneNube = true;

        this.anchoPuerta = 5.0;
        this.altoPuerta = 8.0;
        this.materialPuerta = "Papel decorado y pintado a mano";
    }

    @Override
    public String describir() {
        String desc = "--- Descripción de La Casita de Cami ---\n\n";
        desc += "Estructura: Hecha en cartulina blanca, recortada y armada a mano.\n";
        desc += "Techo: " + this.materialTecho + ".\n\n";

        desc += "--- Colores ---\n";
        desc += "* Fachada Principal: " + this.colorPrincipal + ".\n";
        desc += "* Laterales: " + this.colorLateral + ".\n";
        desc += "* Puerta Principal: Color " + this.colorPuerta + ".\n";
        desc += "* Ventanas: Azul claro con detalles en marcador negro.\n\n";

        desc += "--- Decoraciones ---\n";
        desc += "* " + this.decoraciones + ".\n";
        desc += "* Total de flores dibujadas: " + this.totalFloresDibujadas + ".\n";
        desc += "* ¿Tiene sol?: " + (this.tieneSol ? "Sí" : "No") + ".\n";
        desc += "* ¿Tiene nube?: " + (this.tieneNube ? "Sí" : "No") + ".\n\n";

        desc += "--- Detalles de la Puerta ---\n";
        desc += "* Material: " + this.materialPuerta + ".\n";
        desc += "* Dimensiones: " + this.anchoPuerta + " cm x " + this.altoPuerta + " cm.\n";

        return desc;
    }

    @Override
    public void pintar(String nuevoColor) {
        super.pintar(nuevoColor);
        this.colorPrincipal = nuevoColor;
        System.out.println("La FACHADA de la casita ha sido pintada de color " + nuevoColor);
    }

    public void pintarPuerta(String nuevoColor) {
        this.colorPuerta = nuevoColor;
        System.out.println("La PUERTA ha sido pintada de color " + nuevoColor);
    }

    public void pintarTecho(String nuevoColor) {
        this.materialTecho = "Cartulina pintada de color " + nuevoColor;
        System.out.println("El TECHO ha sido pintado de color " + nuevoColor);
    }
}

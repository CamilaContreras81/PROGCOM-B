package Floristeria;

public class Floristeria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Casa camiCasa= new Casa("Blanca con rosado",5,2,true,true);
		System.out.println(camiCasa.describir());
		camiCasa.pintar("Le agrego el T1");
		System.out.println(camiCasa.describir());

	}

}
